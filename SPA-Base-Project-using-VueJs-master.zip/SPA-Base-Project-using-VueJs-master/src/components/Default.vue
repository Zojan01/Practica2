<template>
  <div>
    <h2>Dashboard</h2>
    <p>La siguiente aplicación contiene:</p>
    <ul>
      <li><b>Vue</b>: nuestro framework para crear componentes</li>
      <li><b>Vuex</b>: para compartir recursos entre toda la aplicación.</li>
      <li><b>VueRouter</b>: para generar un router que nos permita navegar por las URL.</li>
      <li><b>Axios</b>: para trabajar las peticiones AJAX.</li>
      <li><b>Element Ui</b>: como bootstrap pero hecho y pensando para Vue.</li>
    </ul>
    <p>Proyecto base desarrollado por Anexsoft. Para visualizar un módulo desarrollado ingresa al menú de Ejemplo.</p>
  </div>
</template>

<script>
export default {
  name: 'Default'
}
</script>